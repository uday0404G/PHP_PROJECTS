<?php

include "config.php";
 $id=$_REQUEST['idd'];
    $name=$_REQUEST['name1'];
    
    $ingu=$_REQUEST['in'];
    $gu=$_REQUEST['gu'];
    
    $ineng=$_REQUEST['in1'];
    $eng=$_REQUEST['eng'];
    
    $ineco=$_REQUEST['in2'];
    $eco=$_REQUEST['eco'];
    
    $inacc=$_REQUEST['in3'];
    $acc=$_REQUEST['acc'];
    
    $insta=$_REQUEST['in4'];
    $sta=$_REQUEST['sta'];
    
    $incom=$_REQUEST['in5'];
    $com=$_REQUEST['com'];


    $sql="UPDATE `res` SET `name`='$name',`gujrati`='$gu',`english`='$eng',`account`='$acc',`economics`='$eco',`statistic`='$sta',`computer`='$com',`inguj`='$ingu',`ineng`='$ineng',`ineco`='$ineco',`inacc`='$inacc',`insta`='$insta' ,`incom`='$com'WHERE `id`=$id";
   
    
    $res=mysqli_query($con,$sql);

if($res)
{
    header("location:include.php");
}
else
{
  echo "<script>alert('Not Updated')</script>";
}
?>