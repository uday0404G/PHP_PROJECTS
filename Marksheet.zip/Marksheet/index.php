<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<style>
     @font-face{
        font-family: a;
        src:url(gutenberggothic.ttf);
    }
</style>
</head>
<body>
<!--  -->

        <form  method="GET" name="f1" class="m-auto w-25">
            <label for="">Enter Your Roll Number:</label><br>
     <input type="text" name="id" id="aa" class="form-control"><br>
     <input type="submit" value="submit"class="ms-5" onclick="event.preventDefault(); User(document.getElementById('aa').value);">
    </form><br>
    <p id="txt" class="m-auto text-center">YOUR RESULT HEAR......</p>
</body>
<script>
            function User(str)
            {
                if(str== "")
                {
                    document.getElementById('txt').innerHTML="";
                    return;
                }
                else
                {
                    if(window.XMLHttpRequest)
                    {
                        a = new XMLHttpRequest();
                    }
                    a.onreadystatechange = function()
                    {
                        if(this.readyState == 4 && this.status == 200)
                        {
                            document.getElementById('txt').innerHTML = this.responseText;
                        }
                    }
                    a.open("GET","select.php?id="+str,true);
                    a.send();
                }
            }
        </script>


</html>