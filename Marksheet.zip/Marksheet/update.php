<?php
include "config.php";
$id=$_REQUEST['id'];
$sql="SELECT * FROM `res` WHERE `id`='$id'";
$res=mysqli_query($con,$sql);


     
while($row=mysqli_fetch_assoc($res))
{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<style>
     @font-face{
        font-family: a;
        src:url(gutenberggothic.ttf);
    }
</style>
</head>
<body>
    

  <div class="container-fluid m-auto  border border-1 border-dark" style="height:auto;  width: 30%;">
    <h1 class="text-center">Marksheet</h1>
<form action="updated.php" method="POST">
    <label for="">Enter Name:</label>

    <input type="text" name="name1" id="name" id class="form-control" value="<?php echo $row['name']?>">
    <label for="">Enter GR ID:</label>
    <input type="text" name="idd" id="id" class="form-control" value="<?php echo $row['id']?>"><br>

<table border="1" class="w-100 table table-striped table-dark">
    <tr>
        <th scope="col">Subject</th>
        <th scope="col">Total Mark</th>
        <th scope="col">INTERNAL</th>
        <th scope="col">THEORYMARK</th>
    </tr>
    <tr>
        <td>Gujrati</td>
        <td>100</td>
        <td>
            <input type="text" name="in" id="i"  class="form-control" value="<?php echo $row['inguj']?>">
        </td>
        <td>
            <input type="text" name="gu" id="g"  class="form-control" value="<?php echo $row['gujrati']?>">
        </td>
    </tr>
    
    <tr>
        <td>English</td>
        <td>100</td>
        <td>
            <input type="text" name="in1" id="i1"  class="form-control" value="<?php echo $row['ineng']?>">
        </td>
        <td>
            <input type="text" name="eng" id="e"  class="form-control" value="<?php echo $row['english']?>">
        </td>
    </tr>
    
    <tr>
        <td>Economics</td>
        <td>100</td>
        <td>
            <input type="text" name="in2" id="i2"  class="form-control" value="<?php echo $row['ineco']?>">
        </td>
        <td>
            <input type="text" name="eco" id="eco"  class="form-control" value="<?php echo $row['economics']?>">
        </td>
    </tr>
    
    <tr>
        <td>Account</td>
        <td>100</td>
        <td>
            <input type="text" name="in3" id="i3"  class="form-control" value="<?php echo $row['inacc']?>">
        </td>
        <td>
            <input type="text" name="acc" id="A"  class="form-control" value="<?php echo $row['account']?>">
        </td>
    </tr>   
    
    <tr>
        <td>Statistics</td>
        <td>100</td>
        <td>
            <input type="text" name="in4" id="i4"  class="form-control" value="<?php echo $row['insta']?>">
        </td>
        <td>
            <input type="text" name="sta" id="s"  class="form-control" value="<?php echo $row['statistic']?>">
        </td>
    </tr>
    
    <tr>
        <td>Computer</td>
        <td>100</td>
        <td>
            <input type="text" name="in5" id="i5"  class="form-control" value="<?php echo $row['incom']?>">
        </td>
        <td>
            <input type="text" name="com" id="co"  class="form-control" value="<?php echo $row['computer']?>">
        </td>
    </tr>
</table>
<div class="text-center">
<input type="submit"  class="btn btn-outline-warning "  value="Genrate">
</div>
  </div>  
  </form>
  
 
</body>
</html>
<?php
}
?>