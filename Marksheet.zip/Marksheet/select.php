<?php
include "config.php";
$id=intval($_GET['id']);



$sql="SELECT * FROM `res` WHERE `id`='".$id."'";
$res1=mysqli_query($con,$sql);




// include "config.php";
// $id=intval($_GET['id']);
// $sql="SELECT * FROM `employee` WHERE `id`='".$id."'";

// $res=mysqli_query($con,$sql);

?>
 

<?php
while($row=mysqli_fetch_assoc($res1))
{

    if($row['gujrati']<33||$row['english']<33||$row['economics']<33||$row['account']<33||$row['statistic']<33||$row['computer']<33)
{
    $res2="FAILL";
}
else{
    $res2="PASS";

}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<style>
    @font-face{
        font-family: a;
        src:url(gutenberggothic.ttf);
    }
</style>
</head>
<body>

    <div class="container w-75 border border-1 border-dark " style="height:auto;">
        <nav class="navbar  row"  style="height:auto;">
            <div class="col-2 text-center"style="height:auto%;">
                <img src="logo.png" alt="" class="img-fluid h-100 navbar-brand">
            </div>
            <div class="col-10">
                <h2>ગુજરાત માધ્યમિક અને ઉચ્ચતર માધ્યમિક શિક્ષણ બોર્ડ, ગાંધીનગર</h2>
                <h1 style="font-family: a;">Gujarat Secondary and Higher Secondary Education Board, Gandhinagar </h1>
                <h3>ગુણપત્રક-ઉચ્ચતર માધ્યમિક પ્રમાણપત્ર પરીક્ષા - 2024</h3>
                <h4>Statement of Marks - Higher Secondary Certificate Examination - 2010</h4>
            </div>
            </nav>
            <div class="m-1 border border-1 border-dark">
             <table class="table table-striped text-center">
                <tr>
                    <th>MONTH & YEAR OF EXAM</th>
                    <th>CENTER NO.</th>
                    <th>SCHOOL INDEX NO.</th>
                    <th>STREAM</th>
                    <th>SR.NO.OF STATMENT</th>               
                </tr>
                <tr>
                    <th>MARCH-2024</th>
                    <th>004</th>
                    <th>01.042</th>
                    <th>GENERAL</th>
                    <th>603304</th>               
                </tr>
                <tr>
                    <th>SEAT NO.</th>
                    <th colspan="10">CANDIDATE NAME</th>                  
                </tr>
                
                <tr>
                    <td><input type="text" name="" id="id1" readonly class="form-control text-center" value="<?php echo $row['id'];?>"></td>
                    <td colspan="10">
                        <input type="text" name="" id="name1" class="form-control text-center" readonly value="<?php echo $row['name'];?>">
                    </td>                  
                </tr>
             </table>
             <table class="table table-striped text-center">
                    <tr>
                        <th>NAME OF THE SUBJECT</th>
                        <th>TOTAL MARK</th>
                        <th>INTERNAL MARK
                            <p class="h6">OUT OF 30</p>
                        </th>
                        <th>THEORY MARK
                            <p class="h6">OUT OF 70</p>
                        </th>
                        <th>TOTAL
                            <p class="h6">INTERNAL+THEORY=TOTAL</p>
                        </th>
                        <th>PASS/FAILL</th>
                    </tr>
                    <tr>
                        <td>GUJRATI</td>
                        <td>100</td>
                        <td ><input type="text" name="" id="in" value=" <?php echo $row['inguj'];?>"  readonly class="form-control text-center" ></td>
                        <td  ><input type="text" name="" id="th" value=" <?php echo $row['gujrati'];?>"  readonly class="form-control text-center" ></td>
                        <td id="to4"><input type="text" name="" id="th5" value=" <?php $to1= $row['gujrati']+$row['inguj']; echo $to1;?>"  readonly class="form-control text-center" ></td>
                        <td id="gr5">
                        <input type="text" name="" id="th5" value=" <?php
                         if($row['gujrati']<33)
                            {
                                echo "FAILL";
                            }else
                            {
                                echo "PASS";

                            }?>"  readonly class="form-control text-center" >
                        
</td>
                    </tr>
                    <tr>
                        <td>ENGLISH</td>
                        <td>100</td>
                        <td id="in1" ><input type="text" name=""  value="<?php echo $row['ineng'];?>"  readonly class="form-control text-center" ></td>
                        <td id="th1" ><input type="text" name=""  value="<?php echo $row['english'];?>"  readonly class="form-control text-center" ></td>
                        <td id="to4"><input type="text" name="" id="th5" value=" <?php $to2= $row['english']+$row['ineng']; echo $to2;?>"  readonly class="form-control text-center" ></td>
                        <td id="gr5">
                        <input type="text" name="" id="th5" value=" <?php
                         if($row['english']<33)
                            {
                                echo "FAILL";
                            }else
                            {
                                echo "PASS";

                            }?>"  readonly class="form-control text-center" >
                        
</td>
                    </tr>
                    <tr>
                        <td>ECONOMICS</td>
                        <td>100</td>
                        <td id="in2"><input type="text" name=""  value=" <?php echo $row['ineco'];?>"  readonly class="form-control text-center" ></td>
                        <td id="th2"><input type="text" name=""  value=" <?php echo $row['economics'];?>"  readonly class="form-control text-center" ></td>
                        <td id="to4"><input type="text" name="" id="th5" value=" <?php $to3= $row['economics']+$row['ineco']; echo $to3;?>"  readonly class="form-control text-center" ></td>
                        <td id="gr5">
                        <input type="text" name="" id="th5" value=" <?php
                         if($row['economics']<33)
                            {
                                echo "FAILL";
                            }else
                            {
                                echo "PASS";

                            }?>"  readonly class="form-control text-center" >
                        
</td>
                    </tr>
                    <tr>
                        <td>ACCOUNT</td>
                        <td>100</td>
                        <td id="in3"><input type="text" name=""  value=" <?php echo $row['inacc'];?>"  readonly class="form-control text-center" ></td>
                        <td id="th3"><input type="text" name=""  value=" <?php echo $row['account'];?>"  readonly class="form-control text-center" ></td>
                        <td id="to4"><input type="text" name="" id="th5" value=" <?php $to4= $row['account']+$row['inacc']; echo $to4;?>"  readonly class="form-control text-center" ></td>
                        <td id="gr5">
                        <input type="text" name="" id="th5" value=" <?php
                         if($row['account']<33)
                            {
                                echo "FAILL";
                            }else
                            {
                                echo "PASS";

                            }?>"  readonly class="form-control text-center" >
                        
</td>
                    </tr>
                    <tr>
                        <td>SATTISTICS</td>
                        <td>100</td>
                        <td id="th4"><input type="text" name=""  value=" <?php echo $row['insta'];?>"  readonly class="form-control text-center" ></td>
                        <td id="th4"><input type="text" name=""  value=" <?php echo $row['statistic'];?>"  readonly class="form-control text-center" ></td>
                        <td id="to4"><input type="text" name="" id="th5" value=" <?php $to5= $row['statistic']+$row['insta']; echo $to5;?>"  readonly class="form-control text-center" ></td>
                        <td id="gr5">
                        <input type="text" name="" id="th5" value=" <?php
                         if($row['statistic']<33)
                            {
                                echo "FAILL";
                            }else
                            {
                                echo "PASS";

                            }?>"  readonly class="form-control text-center" >
                        
</td>
                        
                    </tr>
                    <tr>
                        <td>COMPUTER</td>
                        <td>100</td>
                        <td ><input type="text" name="" id="in5" value=" <?php echo $row['incom'];?>"  readonly class="form-control text-center" ></td>
                        <td ><input type="text" name="" id="th5" value=" <?php echo $row['computer'];?>"  readonly class="form-control text-center" ></td>
                        <td id="to5"><input type="text" name="" id="th5" value=" <?php $to6= $row['computer']+$row['incom']; echo $to6;?>"  readonly class="form-control text-center" ></td>
                        <td id="gr5">
                        <input type="text" name="" id="th5" value=" <?php
                         if($row['computer']<33)
                            {
                                echo "FAILL";
                            }else
                            {
                                echo "PASS";

                            }?>"  readonly class="form-control text-center" >
                        
</td>
                        
                    </tr>
             </table>
             <table class="table table-striped text-center">
                <tr>
                    <th>TOTAL MARKS OBTAINED</th>
                    <th>TOTAL MARKS</th>
                    <th>RESULT</th>
                    <th>PERCENTAGE</th>
                    <th>GRADE</th>
                </tr>
                <tr>
                    <th id="total"> <?php $total=$to1+$to2+$to3+$to4+$to5+$to6; echo $total; ?></th>
                    <th>600</th>
                    <th id="res2">
                            <?php
                            echo $res2;
                            ?>
                    </th>
                    <th id="per"><?php  $pur=$total/6; echo $pur."%";?></th>
                    <th id="gra"><?php 
                    if($pur>=90 && $pur<=100)
                    {
                        $pur1="SUPERB";
                    }
                    else if($pur>=80 && $pur<=89)
                    {
                        $pur1="FIRST DISTINCTION";
                    }
                    else if($pur>=70 && $pur<=79)
                    {
                        $pur1="FIRST CLASS";
                    }
                    else if($pur>=60 && $pur<=69)
                    {
                        $pur1="SECOND CLASS";
                    }
                    else if($pur>=50 && $pur<=59)
                    {
                        $pur1="THURD CLASS";
                    }
                    else if($pur>=33 && $pur<=49)
                    {
                        $pur1="PASS";
                    }
                    else
                    {
                        $pur1="FAILL";
                    
                    }
                    echo $pur1;?></th>
                </tr>
             </table>
             <table class="table table-striped">
                <tr>
                    <th>TOTAL MARKS OBTAINED IN WORDS</th>
                    <th id="total"></th>
                </tr>
             </table>
             <div class="row">
                <div class="col-6 border">
                    
                    અગત્સનું : આ ગુણપત્રકમાં સહી કરનાર સત્તાધિકારી સિવાય કોઈ ફેરફાર કરી શકશ નહી અને જો કરશે તો ગુણપત્રક રદ થશે અને બોર્ડ કાયદેસરનાં પગલાં લેશે <br>
                    IMPORTANT: Any change in this statement, except by the issuing authority, will result into cancellation of the statement and shall also Invoke imposition of appropriate legal action
                    <hr>
                    GRADE: Grade One (With Distinction): 70% and above <br>
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Grade One: 60% and above, but below 70% <br>
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Grade Two: 45% and above, but below 60% <br>
                           &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Grade Three: To all other candidates, including the exempted
                           <hr>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Passing Standard for Disabled students is 20% 
                           <hr>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #Passing Standard for English - 013 (SL) Subject is 20% 
                </div>
                <div class="col-2 border d-flex align-items-center">
                    <img src="logo.png" alt="" class="img-fluid  navbar-brand">
                </div>
                <div class="col-4 border pt-5">
                    <p>XO: Indicates Exemption' (35%) () **Indic Deficiency Condoned which is not included in M obtained. (ii) AO: Indicates 'Absent'</p>
                    <div class=" d-flex align-items-end pt-5 flex-wrap text-center">
                    <img src="s.jpg" alt="" class="img-fluid  navbar-brand"><br><br>
                    <hr>
                        (D. S. Patel) परीक्षा सचिव/ EXAMINATION SECRET
                    </div>
                </div>
             </div>
    </div>  
    </div>
    <?php

  

    ?>
</body>
<script src="script.js"></script>
<script>
 

   var i5 = document.getElementById('in5').value;
   var co = document.getElementById('th5').value;

   


var to5=parseInt(i5)+parseInt(co);
console.log(to5);
document.getElementById('to5').innerHTML=to5;
// document.getElementById('to5').innerHTML=to5; 
// if(g<33)
// {
//     document.getElementById('gr').innerHTML="FAILL";
// }else
// {
//     document.getElementById('gr').innerHTML="PASS";

// }
// if(e<33)
// {
//     document.getElementById('gr1').innerHTML="FAILL";
// }else
// {
//     document.getElementById('gr1').innerHTML="PASS";

// }
// if(a<33)
// {
//     document.getElementById('gr2').innerHTML="FAILL";
// }else
// {
//     document.getElementById('gr2').innerHTML="PASS";

// }
// if(eco<33)
// {
//     document.getElementById('gr3').innerHTML="FAILL";
// }else
// {
//     document.getElementById('gr3').innerHTML="PASS";

// }
// if(s<33)
// {
//     document.getElementById('gr4').innerHTML="FAILL";
// }else
// {
//     document.getElementById('gr4').innerHTML="PASS";

// }
// if(co<33)
// {
//     document.getElementById('gr5').innerHTML="FAILL";
// }else
// {
//     document.getElementById('gr5').innerHTML="PASS";

// }

// var total=parseInt(to)+parseInt(to1)+parseInt(to2)+parseInt(to3)+parseInt(to4)+parseInt(to5);
// document.getElementById('total').innerHTML=total;
// if(g<33||e<33||a<33||eco<33||s<33||co<33)
// {
//     document.getElementById('res').innerHTML="FAILL";
// }
// else{
//     document.getElementById('res').innerHTML="PASS";
// }
// var pur=total/6;
// document.getElementById('per').innerHTML=pur+"%";
// if(pur>90 && pur<100)
// {
//     document.getElementById('gra').innerHTML="SUPERB";
// }
// else if(pur>80 && pur<89)
// {
//     document.getElementById('gra').innerHTML="FIRST DISTINCTION";
// }
// else if(pur>70 && pur<79)
// {
//     document.getElementById('gra').innerHTML="FIRST CLASS";
// }
// else if(pur>60 && pur<69)
// {
//     document.getElementById('gra').innerHTML="SECOND CLASS";
// }
// else if(pur>50 && pur<59)
// {
//     document.getElementById('gra').innerHTML="THURD CLASS";
// }
// else if(pur>33 && pur<49)
// {
//     document.getElementById('gra').innerHTML="PASS";
// }
// else
// {
//     document.getElementById('gra').innerHTML="FAILL";

// }


</script>
</html>
<?php
}
?>
