create database student;

use student;

CREATE TABLE `adtocart`.`res` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `gujrati` int(11) NOT NULL,
  `english` int(11) NOT NULL,
  `account` int(11) NOT NULL,
  `economics` int(11) NOT NULL,
  `statistic` int(11) NOT NULL,
  `computer` int(11) NOT NULL,
  `inguj` int(11) NOT NULL,
  `ineng` int(11) NOT NULL,
  `ineco` int(11) NOT NULL,
  `inacc` int(11) NOT NULL,
  `insta` int(11) NOT NULL,
  `incom` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

 